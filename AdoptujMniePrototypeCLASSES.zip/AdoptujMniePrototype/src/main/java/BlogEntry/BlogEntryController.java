package BlogEntry;

public class BlogEntryController {
}
