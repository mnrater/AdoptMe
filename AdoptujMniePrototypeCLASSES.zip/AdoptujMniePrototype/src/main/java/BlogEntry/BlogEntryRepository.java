package BlogEntry;

public interface BlogEntryRepository {
}
