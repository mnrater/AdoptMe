package BlogEntry;

public class BlogEntryService {
}
