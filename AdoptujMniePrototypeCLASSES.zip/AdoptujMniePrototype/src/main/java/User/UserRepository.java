package User;

public interface UserRepository {
}
