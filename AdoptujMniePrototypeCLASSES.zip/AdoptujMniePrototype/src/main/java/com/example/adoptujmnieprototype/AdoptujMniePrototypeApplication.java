package com.example.adoptujmnieprototype;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdoptujMniePrototypeApplication {

    public static void main(String[] args) {
        SpringApplication.run(AdoptujMniePrototypeApplication.class, args);
    }

}
