package ApplicationProcess;

public interface ApplicationProcessRepository {
}
