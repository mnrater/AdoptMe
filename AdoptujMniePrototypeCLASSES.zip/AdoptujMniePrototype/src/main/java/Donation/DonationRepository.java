package Donation;

public interface DonationRepository {
}
