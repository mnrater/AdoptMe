package Shelter;

public interface ShelterRepository {
}
