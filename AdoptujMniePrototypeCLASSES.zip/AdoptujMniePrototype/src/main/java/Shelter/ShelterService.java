package Shelter;

public class ShelterService {
}
