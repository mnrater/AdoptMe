package Payment;

public interface PaymentRepository {
}
