package AdoptionMeeting;

public class AdoptionMeetingService {
}
