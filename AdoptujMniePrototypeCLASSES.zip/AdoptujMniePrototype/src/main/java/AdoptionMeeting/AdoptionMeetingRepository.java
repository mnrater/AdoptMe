package AdoptionMeeting;

public interface AdoptionMeetingRepository {
}
