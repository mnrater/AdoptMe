package AdoptionMeeting;

public class AdoptionMeetingController {
}
