package com.example.adoptujmnieprototype;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdoptujMniePrototypeApplicationTests {

    @Test
    void contextLoads() {
    }

}
